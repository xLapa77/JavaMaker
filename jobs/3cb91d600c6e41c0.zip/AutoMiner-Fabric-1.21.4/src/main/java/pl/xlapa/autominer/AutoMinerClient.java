package pl.xlapa.autominer;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import org.lwjgl.glfw.GLFW;

public final class AutoMinerClient implements ClientModInitializer {
    private static KeyBinding toggleKey;
    private static boolean enabled = false;
    private static BlockPos currentTarget = null;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.autominer.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_H,
                "category.autominer"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                currentTarget = null;
                if (client.player != null) {
                    client.player.sendMessage(
                            net.minecraft.text.Text.literal("[AutoMiner] " + (enabled ? "§aWŁĄCZONY" : "§cWYŁĄCZONY")),
                            true
                    );
                }
            }

            if (!enabled || client.player == null || client.world == null || client.interactionManager == null) {
                currentTarget = null;
                return;
            }

            HitResult hit = client.crosshairTarget;
            if (hit == null || hit.getType() != HitResult.Type.BLOCK) {
                currentTarget = null;
                return;
            }

            BlockHitResult blockHit = (BlockHitResult) hit;
            BlockPos targetPos = blockHit.getBlockPos();
            World world = client.world;
            BlockState state = world.getBlockState(targetPos);
            if (state.isAir() || !state.getFluidState().isEmpty()) {
                currentTarget = null;
                return;
            }

            Direction side = blockHit.getSide();
            if (currentTarget == null || !currentTarget.equals(targetPos)) {
                client.interactionManager.attackBlock(targetPos, side);
                currentTarget = targetPos.toImmutable();
            }

            // Keep vanilla's normal mining progress running for the targeted block.
            boolean stillBreaking = client.interactionManager.updateBlockBreakingProgress(targetPos, side);
            if (!stillBreaking || world.getBlockState(targetPos).isAir()) {
                currentTarget = null;
            }
        });
    }
}
