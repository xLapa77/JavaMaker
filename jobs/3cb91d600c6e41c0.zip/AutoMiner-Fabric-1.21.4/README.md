# AutoMiner — Fabric 1.21.4

Client-side Fabric mod. Press **H** to toggle automatic mining of the solid block currently under your crosshair. Press H again to stop.

## Requirements
- Minecraft Java Edition 1.21.4
- Fabric Loader 0.16.10 or newer for Minecraft 1.21.4
- Fabric API for 1.21.4
- Java 21 (for building)

## Build the JAR
1. Install JDK 21 and Gradle 8.11 compatible with Fabric Loom 1.9.2.
2. Open a terminal in this folder.
3. Run `gradle build` (Windows: `gradle.bat build` if using a local Gradle installation).
4. The mod JAR will be created at `build/libs/AutoMiner-Fabric-1.21.4-1.0.0.jar`.
5. Put the JAR in your Minecraft instance's `mods` folder alongside Fabric API.

Gradle downloads Minecraft/Fabric dependencies on the first build, so an internet connection is required.

## Notes
- This is client-side automation and may be blocked or prohibited on multiplayer servers. Check the server rules before using it.
- It targets the block already selected by the crosshair; it does not scan through walls or choose blocks on its own.
