package com.example.modtest;
import net.fabricmc.api.ModInitializer;
public class ModTest implements ModInitializer {
  @Override public void onInitialize() { System.out.println("ModTest dziala!"); }
}
