package pl.test;
public class TokenCheck {
    public static void main(String[] args) { System.out.println("ok"); }
}
